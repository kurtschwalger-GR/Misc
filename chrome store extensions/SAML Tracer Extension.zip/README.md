SAML Tracer
===========

SAML Tracer is a simple Chrome extension that allows you to view 
SAML messages being sent between your browser and the identity provider. 
It is a useful tool for debugging SAML issues. 
This extension is a fork of the original SAML Tracer, 
which was created by SimpleSAMLphp. 
You can check it out [here](https://github.com/simplesamlphp/SAML-tracer). 
This extension is available on the Chrome Web Store.

SAML Tracer makes use of open-source software. 
You can review the original license text in attribution.md.
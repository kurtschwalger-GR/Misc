// Table helper functions for creating HTML tables with headers and rows

SAMLTrace.TableHelpers = {
  appendHeader(table, text) {
    const th = document.createElement("th");
    th.innerText = text;
    th.colSpan = 2;
    th.style.textAlign = "left";
    th.style.borderTop = "1px solid #ddd";
    th.style.borderBottom = "1px solid #ddd";
    th.style.padding = "5px";

    const tr = document.createElement("tr");
    tr.appendChild(th);

    table.appendChild(tr);
  },

  appendRow(table, key, value, isElement) {
    if (value) {
      const tdKey = document.createElement("td");
      tdKey.classList.add("bottom-item-request-info-keyword")
      tdKey.innerText = `${key}:`;

      const tdValue = document.createElement("td");
      if (isElement) {
        tdValue.appendChild(value);
      } else {
        tdValue.innerText = value;
      }

      const tr = document.createElement("tr");
      tr.appendChild(tdKey);
      tr.appendChild(tdValue);

      table.appendChild(tr);
    }
  }
};

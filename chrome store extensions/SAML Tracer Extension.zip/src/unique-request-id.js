// Unique request ID generator using hash of URL

SAMLTrace.UniqueRequestId = function(webRequestId, method, url) {
  this.webRequestId = webRequestId;
  this.method = method;
  this.url = url;
};

SAMLTrace.UniqueRequestId.prototype = {
  create(onCreated) {
    Hash.calculate(this.url).then(digest => onCreated("request-" + this.webRequestId + "-" + this.method + "-" + digest));
  }
};

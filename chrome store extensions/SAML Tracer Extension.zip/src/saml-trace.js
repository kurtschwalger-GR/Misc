// forked from https://github.com/simplesamlphp/SAML-tracer/blob/main/src/SAMLTrace.js
// Main namespace initialization
if ("undefined" == typeof(SAMLTrace)) {
  var SAMLTrace = {}; // global scope
}
